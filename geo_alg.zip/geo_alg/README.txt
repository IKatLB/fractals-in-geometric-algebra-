this project generates fractals in arbitrary dimension up to G4 in geometric algebra.
This is limited to 2 dimensional graphs but could easily be expanded on. 
This "brute force method" is not ideal and if I knew how to define a distance function to an arbitrary fractal you could ray trace 3 dimensional fractals as was done in this paper
Wareham, R.J., Lasenby, J. Generating Fractals Using Geometric Algebra. Adv. Appl. Clifford Algebras 21, 647–659 (2011). https://doi.org/10.1007/s00006-010-0265-1