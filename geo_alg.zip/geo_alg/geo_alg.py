

from clifford.g4 import *
import matplotlib.pyplot as plt




step_number = 100 #changes clarity of image, also leading change in time, time complexity O(n^2) since we are analyzing an nXn grid
x_axis_blade = '' 
y_axis_blade = 'e12' #blades are defined in the multivectors.py file
x_start = -2 
x_stop = 2
y_start = -2
y_stop = 2 #defines the range of the data we are graphing
julia_set = False #set to True to generate julia set instead of mandelbrot set
constant = 0 #recursion starting value

iteration_number = 100 #determines number of times recursion is done, 100 seems to be sufficient
plot_point_size = 0.5



def z(c,i): #one step of recursion function, change power to get different shapes
    return(c**2+i)


def div_test(input,constant_local,iteration_number_local:int) -> bool: 
    """
    The `div_test` function determines whether a given input value,
    after undergoing a specified multivector of iterations through a recursive function `z`, will result in a final magnitude less than 1000.
    constant is used simulary to how it is when generating julia sets, changes constant added each step from intial input to constant
    """
    
    for step in range(iteration_number_local):
        input = z(input,constant_local)
    if abs(input) < 100:
        return(True)
    else:
        return(False) 


def make_grid(x_axis_blade_local, y_axis_blade_local, step_number_local:int,iteration_number_local:int,constant_local,x_start_local, x_stop_local,y_start_local,y_stop_local,js_local) -> tuple:
    """
    whole lotta inputs due to other functions called inside. puts out a tuple of x and y values in a list for matplotlip to plot
    """
    x_range = x_stop_local-x_start_local # define range of data view
    y_range = y_stop_local-y_start_local
    x_step_value = x_range/step_number_local #find the value of one step based on range and the number of steps we are taking
    y_step_value = y_range/step_number_local #ie. range of data is between 0 and 10 we want 10 steps so step value is 1
    X = []
    Y = []
    if js_local:
        for i in range(step_number_local):
            for j in range(step_number_local): #nested for loops :( dont know how/if I can avoid
                x = (x_start_local + i*x_step_value) #define current x/y value. start at starting value then move up i/j number of steps to find point in the grid
                y = (y_start_local + j*y_step_value)
                coordinate = x*blades[x_axis_blade_local]+y*blades[y_axis_blade_local] #define multivector based on what blades we are graphing
                converges = div_test(coordinate,constant_local,iteration_number_local) #use div_test to determine if it will converge
                if converges:    
                    X.append(x) #add to x/y values if it converges
                    Y.append(y)
    else:
        for i in range(step_number_local):
            for j in range(step_number_local): #nested for loops :( dont know how/if I can avoid
                x = (x_start_local + i*x_step_value) #define current x/y value. start at starting value then move up i/j number of steps to find point in the grid
                y = (y_start_local + j*y_step_value)
                coordinate = x*blades[x_axis_blade_local]+y*blades[y_axis_blade_local] #define multivector based on what blades we are graphing
                converges = div_test(constant_local,coordinate,iteration_number_local) #use div_test to determine if it will converge
                if converges:    
                    X.append(x) #add to x/y values if it converges
                    Y.append(y)
        
    grid = (X,Y)    
    return(grid)

plots = make_grid(x_axis_blade,y_axis_blade,step_number,iteration_number,constant,x_start,x_stop,y_start,y_stop,julia_set) #based on global variables above
X = plots[0]
Y = plots[1]
ax = plt.scatter(X,Y, s = plot_point_size) #data will only be graphed if it converges so your range could be large but data graphed small becuase small amount converged
if x_axis_blade == '':
    plt.xlabel('scaler input quantity')
else:
    plt.xlabel('scaler part of ' + x_axis_blade + ' input')
if y_axis_blade == '':
    plt.ylabel('scaler input quantity')
else:
    plt.ylabel('scaler part of ' + y_axis_blade + ' input')

plt.title('z**2 + c, z0 = ' + str(constant))
plt.show()
